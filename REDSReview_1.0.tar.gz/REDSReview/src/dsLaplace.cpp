#include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]
NumericVector dsLaplace(NumericVector uni, double location = 0.0, double scale = 1.0) {
  int n = uni.size();
  NumericVector sample1(n);
  
  for (int i = 0; i < n; i++) {
    double u = uni[i];
    double sgn = (u - 0.5 < 0) ? -1.0 : 1.0;
    sample1[i] = location - sgn * scale * (log(2.0) + ((u < 0.5) ? log(u) : log1p(-u)));
  }
  
  return sample1;
}

/*
 Copyright 2023 Tuobang Li
 This is a test code that is currently under review in PNAS, please do not share it.
 */
