// C++ code

#include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]
NumericVector dsRayleigh(NumericVector uni, double scale = 1.0) {
  int n = uni.size();
  NumericVector sample1(n);
  
  for (int i = 0; i < n; i++) {
    if (scale > 0) {
      sample1[i] = scale * sqrt(-2 * log(uni[i]));
    } else {
      sample1[i] = NA_REAL;
    }
  }
  return rev(sample1);
}

/*
 Copyright 2023 Tuobang Li
 This is a test code that is currently under review in PNAS, please do not share it.
 */
