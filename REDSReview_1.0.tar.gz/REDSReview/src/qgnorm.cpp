#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::depends(RcppArmadillo)]]


double sign(double x) {
  if (x == 0.0) {
    return 0.0;
  } else {
    return (x > 0) ? 1.0 : -1.0;
  }
}

// [[Rcpp::export]]
NumericVector qgnorm(NumericVector p, double mu = 0, double alpha = 1, double beta = 1, bool lower_tail = true, bool log_p = false) {

  if (alpha <= 0 || beta <= 0) {
    Rcpp::Rcout << "Not defined for negative values of alpha and/or beta.\n";
    return NumericVector(p.length(), NumericVector::get_na());
  }

  NumericVector q_val(p.length());

  for (int i = 0; i < p.length(); ++i) {
    double curr_p = p[i];

    if (!lower_tail && !log_p) {
      curr_p = 1.0 - curr_p;
    } else if (!lower_tail && log_p) {
      curr_p = log(1.0 - curr_p);
    } else if (lower_tail && log_p) {
      curr_p = exp(curr_p);
    }

    double lambda = pow(1.0/alpha, beta);

    double sign_val = sign(curr_p - 0.5);
    double gamma_val = R::qgamma(fabs(curr_p - 0.5) * 2.0, 1.0/beta, 1.0/lambda, 1, 0);
    double q_curr = pow(gamma_val, 1.0/beta) * sign_val + mu;

    q_val[i] = q_curr;
  }

  return q_val;
}

/*
 Copyright 2023 Tuobang Li
 This is a test code that is currently under review in PNAS, please do not share it.
 */
