#include <Rcpp.h>
#include <cmath>

using namespace Rcpp;

// [[Rcpp::export]]
NumericVector dsPareto(NumericVector uni, double shape, double scale = 1.0) {
  int n = uni.size();
  NumericVector sample1(n);
  
  for (int i = 0; i < n; i++) {
    double u = uni[i];
    if (scale <= 0.0 || shape <= 0.0 || u <= 0.0) {
      sample1[i] = NAN;
    } else {
      sample1[i] = scale * pow(u, -1.0/shape);
    }
  }
  
  return rev(sample1);
}

/*
 Copyright 2023 Tuobang Li
 This is a test code that is currently under review in PNAS, please do not share it.
 */
