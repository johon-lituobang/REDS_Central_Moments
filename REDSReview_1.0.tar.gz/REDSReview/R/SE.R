#Copyright 2023 Tuobang Li
#This is a test package that is currently under review in PNAS, please do not share it.

se_mean<-function (x){
  x<-as.numeric(x)
  n<-length(x)
  usd<-unbiasedsd(x)
  usd/sqrt(n)
}
se_sd<-function (x){
  x<-as.numeric(x)
  n<-length(x)
  unbiasedmoments1<-unbiasedmoments(x)
  sqrt((unbiasedmoments1[4]/(4*n*unbiasedmoments1[2]))-((n-3)/(4*n*(n-1)))*unbiasedmoments1[2])
}
calculate_column_mean<-function(x){
  x<-as.numeric(x)
  if (any(is.na(x))) {
    return(Inf)
  } else {
    return(mean(x, na.rm = TRUE))
  }
}
calculate_column_sd <- function(x) {
  x<-as.numeric(x)
  if (any(is.na(x))) {
    return(Inf)
  } else {
    return(unbiasedsd(x))
  }
}

