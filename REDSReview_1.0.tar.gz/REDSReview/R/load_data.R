#Copyright 2023 Tuobang Li
#This is a test package that is currently under review in PNAS, please do not share it.
data(Imoments_values, package = "REDSReview")
data(I_values, package = "REDSReview")
data(d_values, package = "REDSReview")
data(quasiuni_2_104, package = "REDSReview")
data(quasiuni_3_104, package = "REDSReview")
data(quasiuni_4_104, package = "REDSReview")
data(quasiuni_5_104, package = "REDSReview")
