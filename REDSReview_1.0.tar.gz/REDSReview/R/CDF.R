#Copyright 2023 Tuobang Li
#This is a test package that is currently under review in PNAS, please do not share it.

CDF<-function(x,xevaluated,sorted=FALSE,HF=FALSE){
  if(!sorted){
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if(HF){
    #Hyndman, Rob J., and Yanan Fan. “Sample Quantiles in Statistical Packages.” The American Statistician, vol. 50, no. 4, 1996, pp. 361–65. JSTOR, https://doi.org/10.2307/2684934. Accessed 24 Oct. 2023.
    quantile2<-min(which(sortedx>(xevaluated)))-1
    if(is.infinite(quantile2)){
      quantile2=length(sortedx)
    }
    sortedquantile2<-sortedx[quantile2+1]
    if(quantile2==0){
      sortedquantile21<-sortedx[1]
    }else if(quantile2==-1){
      sortedquantile21<-sortedx[1]
    }else{
      sortedquantile21<-sortedx[quantile2]
    }
    if(sortedquantile21==sortedquantile2){
      result<-(quantile2)/lengthx
    }else{
      result<-((xevaluated-sortedquantile21)/(sortedquantile2-sortedquantile21)+quantile2)/lengthx
    }
    
    #will update later
    return(result)
  }
  n<-length(x)
  quantileTargets<-((1:n)-1)/(n-1)
  
  interpolation_function<-approxfun(x,quantileTargets,method="linear",rule=2)
  approxQuantileTarget<-interpolation_function(xevaluated)

  approxQuantileTarget
}



quantilefunction<-function(x,quatiletarget,sorted=FALSE,HF=FALSE){
  if(!sorted){
    x <- Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if(HF){
    #Hyndman, Rob J., and Yanan Fan. “Sample Quantiles in Statistical Packages.” The American Statistician, vol. 50, no. 4, 1996, pp. 361–65. JSTOR, https://doi.org/10.2307/2684934. Accessed 24 Oct. 2023.
    lengthx<-length(x)
    h1<-(lengthx+1/3)*quatiletarget+1/3
    h1f<-as.numeric(floor(h1))
    h1c<-as.numeric(ceiling(h1))
    sortedquantile1<-sortedx[h1f]
    sortedquantile2<-sortedx[h1c]
    result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
    names(result)<-quatiletarget
    #will update later
    return(result)
  }
  lengthx<-length(x)
  h1<-(lengthx-1)*quatiletarget+1
  h1f<-as.numeric(floor(h1))
  h1c<-as.numeric(ceiling(h1))
  sortedquantile1<-x[h1f]
  sortedquantile2<-x[h1c]
  result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
  names(result)<-quatiletarget
  (result)
}
# 
# d_adjust_kurt<-function(size,dtype,kurt1,dlist,etype){
#   dlist<-dlist[dlist[,2] == dtype,]
#   dlist<-dlist[,c(1:4,etype)]
#   if(size%in% dlist[,1]){
#     if (kurt1%in% dlist[dlist[,1] == size,3]){
#       result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,5]
#     }else{
#       rown2<-as.numeric(dlist[dlist[,1] == size,3])
#       tryCatch({
#         infn2 <- max(rown2[rown2 <= kurt1])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
#         message(custom_warning)
#         infn2 <<- min(rown2)
#       })
# 
#       tryCatch({
#         supn2 <- min(rown2[rown2 >= kurt1])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
#         message(custom_warning)
#         supn2 <<- max(rown2)
#       })
# 
#       if(supn2==infn2){
#         result1<-dlist[dlist[,1]==size & dlist[,3]==infn2,5]
#       }else{
#         d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,5]
#         d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,5]
#         result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
#       }
#     }
#   }else{
#     rown<-as.numeric(dlist[,1])
# 
#     tryCatch(
#       {
#         infn <- max(rown[rown <= size])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
#         message(custom_warning)
#         infn <<- min(rown)
#       }
#     )
# 
#     tryCatch(
#       {
#         supn<-min(rown[rown >= size])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
#         message(custom_warning)
#         supn <<- max(rown)
#       }
#     )
# 
#     rown2<-as.numeric(dlist[dlist[,1] == infn,3])
# 
#     tryCatch({
#       infn2 <- max(rown2[rown2 <= kurt1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
#       message(custom_warning)
#       infn2 <<- min(rown2)
#     })
# 
#     tryCatch({
#       supn2 <- min(rown2[rown2 >= kurt1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
#       message(custom_warning)
#       supn2 <<- max(rown2)
#     })
# 
#     d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,5]
#     d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,5]
# 
#     if(supn2==infn2){
#       da<-d1
#     }else{
#       da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
#     }
# 
#     rown2<-as.numeric(dlist[dlist[,1] == supn,3])
# 
#     tryCatch({
#       infn2 <- max(rown2[rown2 <= kurt1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
#       message(custom_warning)
#       infn2 <<- min(rown2)
#     })
# 
#     tryCatch({
#       supn2 <- min(rown2[rown2 >= kurt1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
#       message(custom_warning)
#       supn2 <<- max(rown2)
#     })
# 
#     d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,5]
#     d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,5]
# 
#     if(supn2==infn2){
#       db<-d1
#     }else{
#       db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
#     }
# 
#     if(da==db){
#       result1<-da
#     }else{
#       result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
#     }
#   }
#   return(result1)
# }
# 
# d_adjust_skew<-function(size,dtype,skew1,dlist,etype){
#   skew1<-abs(skew1)
#   dlist<-dlist[dlist[,2] == dtype,]
#   dlist<-dlist[,c(1:4,etype)]
#   if(size%in% dlist[,1]){
#     if (skew1%in% dlist[dlist[,1] == size,4]){
#       result1<-dlist[dlist[,1] == size & dlist[,4]==skew1,5]
#     }else{
#       rown2<-as.numeric(dlist[dlist[,1] == size,4])
# 
#       tryCatch({
#         infn2 <- max(rown2[rown2 <= skew1])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
#         message(custom_warning)
#         infn2 <<- min(rown2)
#       })
# 
#       tryCatch({
#         supn2 <- min(rown2[rown2 >= skew1])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
#         message(custom_warning)
#         supn2 <<- max(rown2)
#       })
#       d1<-dlist[dlist[,1]==size & dlist[,4]==infn2,5]
#       d2<-dlist[dlist[,1]==size & dlist[,4]==supn2,5]
#       if(supn2==infn2){
#         result1<-d1
#       }else{
#         result1<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
#       }
#     }
#   }else{
#     rown<-as.numeric(dlist[,1])
#     tryCatch(
#       {
#         infn <- max(rown[rown <= size])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
#         message(custom_warning)
#         infn <<- min(rown)
#       }
#     )
#     tryCatch(
#       {
#         supn<-min(rown[rown >= size])
#       },
#       warning = function(w) {
#         custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
#         message(custom_warning)
#         supn <<- max(rown)
#       }
#     )
# 
#     rown2<-as.numeric(dlist[dlist[,1] == infn,4])
#     tryCatch({
#       infn2 <- max(rown2[rown2 <= skew1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
#       message(custom_warning)
#       infn2 <<- min(rown2)
#     })
#     tryCatch({
#       supn2 <- min(rown2[rown2 >= skew1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
#       message(custom_warning)
#       supn2 <<- max(rown2)
#     })
# 
#     d1<-dlist[dlist[,1]==infn & dlist[,4]==infn2,5]
#     d2<-dlist[dlist[,1]==infn & dlist[,4]==supn2,5]
# 
#     if(supn2==infn2){
#       da<-d1
#     }else{
#       da<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
#     }
# 
#     rown2<-as.numeric(dlist[dlist[,1] == supn,4])
#     tryCatch({
#       infn2 <- max(rown2[rown2 <= skew1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
#       message(custom_warning)
#       infn2 <<- min(rown2)
#     })
#     tryCatch({
#       supn2 <- min(rown2[rown2 >= skew1])
#     },
#     warning = function(w) {
#       custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
#       message(custom_warning)
#       supn2 <<- max(rown2)
#     })
# 
#     d1<-dlist[dlist[,1]==supn & dlist[,4]==infn2,5]
#     d2<-dlist[dlist[,1]==supn & dlist[,4]==supn2,5]
# 
#     if(supn2==infn2){
#       db<-d1
#     }else{
#       db<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
#     }
# 
#     if(da==db){
#       result1<-da
#     }else{
#       result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
#     }
#   }
#   return(result1)
# }

median_of_means <- function(x,korder=2){
    if((round(korder)-korder)!=0){
      n_blocks=ceiling(length(x)/korder)
      n_blocks_floor=floor(n_blocks*(1-korder+floor(korder)))
      n_blocks_ceiling=floor(n_blocks*(1-ceiling(korder)+korder))
      if (korder <= 1) {
        return(median(x))
      }
      data_mixed <- sample(x)
      index_vec <- c(rep(1:n_blocks_ceiling, each = ceiling(korder)),rep((n_blocks_ceiling+1):(n_blocks_floor+n_blocks_ceiling), each = floor(korder)))
      if(length(index_vec)>length(data_mixed)){
        data_mixed <- c(data_mixed,sample(x,size =length(index_vec)-length(data_mixed)))
      }
      data_groups <- split(data_mixed, index_vec)
      block_means <- sapply(data_groups, mean)
    }else{
      n_blocks=ceiling(length(x)/korder)
      if (korder <= 1) {
        return(median(x))
      }
      data_mixed <- sample(x)
      index_vec <- c(rep(1:n_blocks, each = (korder)))[1:length(x)]
      
      data_groups <- split(data_mixed, index_vec)
      block_means <- sapply(data_groups, mean)
      
    }
    return(c(MoM=median(block_means,na.rm = TRUE)))
  }
